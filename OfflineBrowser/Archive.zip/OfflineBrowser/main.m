//
//  main.m
//  OfflineBrowser
//
//  Created by Greg Murray on 12-03-08.
//  Copyright (c) 2012 University of Prince Edward Island. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
