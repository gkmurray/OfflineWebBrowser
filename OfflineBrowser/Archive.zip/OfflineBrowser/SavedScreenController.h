//
//  SavedScreenController.h
//  OfflineBrowser
//
//  Created on 12-03-08.
//

#import <UIKit/UIKit.h>

@interface SavedScreenController : UITableViewController

@end
