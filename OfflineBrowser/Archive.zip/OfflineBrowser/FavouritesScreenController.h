//
//  FavouritesScreenController.h
//  OfflineBrowser
//
//  Created on 12-03-31.
//

#import <UIKit/UIKit.h>

@interface FavouritesScreenController : UITableViewController

@end
